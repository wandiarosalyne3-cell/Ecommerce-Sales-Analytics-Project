
-- E-Commerce Sales Analytics Project
-- SQL schema and analytical queries

CREATE TABLE orders (
    order_id VARCHAR(20) PRIMARY KEY,
    order_date DATE,
    customer_id VARCHAR(20),
    product_id VARCHAR(20),
    product_name VARCHAR(100),
    category VARCHAR(100),
    region VARCHAR(50),
    channel VARCHAR(50),
    quantity INT,
    unit_price DECIMAL(12,2),
    discount DECIMAL(5,2),
    revenue DECIMAL(12,2),
    cost DECIMAL(12,2),
    profit DECIMAL(12,2)
);

-- 1. Total revenue, profit and orders
SELECT
    SUM(revenue) AS total_revenue,
    SUM(profit) AS total_profit,
    COUNT(DISTINCT order_id) AS total_orders
FROM orders;

-- 2. Monthly performance
SELECT
    EXTRACT(YEAR FROM order_date) AS year,
    EXTRACT(MONTH FROM order_date) AS month,
    SUM(revenue) AS revenue,
    SUM(profit) AS profit
FROM orders
GROUP BY EXTRACT(YEAR FROM order_date), EXTRACT(MONTH FROM order_date)
ORDER BY year, month;

-- 3. Revenue by category
SELECT
    category,
    SUM(revenue) AS revenue,
    SUM(profit) AS profit
FROM orders
GROUP BY category
ORDER BY revenue DESC;

-- 4. Top 10 products
SELECT
    product_name,
    SUM(revenue) AS revenue,
    SUM(profit) AS profit,
    SUM(quantity) AS units_sold
FROM orders
GROUP BY product_name
ORDER BY revenue DESC
LIMIT 10;

-- 5. Revenue by region
SELECT
    region,
    SUM(revenue) AS revenue,
    SUM(profit) AS profit
FROM orders
GROUP BY region
ORDER BY revenue DESC;

-- 6. Average order value
SELECT
    SUM(revenue) / COUNT(DISTINCT order_id) AS average_order_value
FROM orders;

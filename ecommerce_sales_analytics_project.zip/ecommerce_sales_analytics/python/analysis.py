
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Load data
df = pd.read_csv("../data/ecommerce_orders.csv", parse_dates=["order_date"])

# Basic cleaning
df = df.drop_duplicates()
df = df.dropna(subset=["order_id", "order_date", "revenue"])
df["revenue"] = pd.to_numeric(df["revenue"], errors="coerce")
df["profit"] = pd.to_numeric(df["profit"], errors="coerce")

# KPIs
total_revenue = df["revenue"].sum()
total_profit = df["profit"].sum()
total_orders = df["order_id"].nunique()
average_order_value = total_revenue / total_orders

print(f"Total revenue: {total_revenue:,.2f}")
print(f"Total profit: {total_profit:,.2f}")
print(f"Total orders: {total_orders:,}")
print(f"Average order value: {average_order_value:,.2f}")

# Monthly analysis
df["month"] = df["order_date"].dt.to_period("M").astype(str)
monthly = df.groupby("month").agg(
    revenue=("revenue", "sum"),
    profit=("profit", "sum"),
    orders=("order_id", "nunique")
).reset_index()

# Category analysis
category = df.groupby("category").agg(
    revenue=("revenue", "sum"),
    profit=("profit", "sum"),
    units=("quantity", "sum")
).reset_index().sort_values("revenue", ascending=False)

print("\nCategory performance:")
print(category)

# Product analysis
top_products = df.groupby("product_name")["revenue"].sum().sort_values(ascending=False).head(10)
print("\nTop 10 products:")
print(top_products)
